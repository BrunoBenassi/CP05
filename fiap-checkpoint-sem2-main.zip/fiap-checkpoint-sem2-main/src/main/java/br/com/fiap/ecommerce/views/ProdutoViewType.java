package br.com.fiap.ecommerce.views;

public enum ProdutoViewType {
    FULL, SIMPLE    
}