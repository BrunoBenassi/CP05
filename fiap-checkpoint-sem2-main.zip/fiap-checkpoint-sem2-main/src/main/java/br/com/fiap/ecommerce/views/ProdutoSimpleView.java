package br.com.fiap.ecommerce.views;

public interface ProdutoSimpleView {
    String getNome();    
}